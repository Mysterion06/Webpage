# TEWSplitter

## Features
  * Chaptersplits
  * Automatic start
  * Timer adjusted to IGT

## Credits
  * [MattMatt] ? (founder/developer)
  * [Mysterion06](https://github.com/Mysterion06) (developer)
