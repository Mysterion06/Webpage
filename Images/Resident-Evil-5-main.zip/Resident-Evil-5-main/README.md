# Resident-Evil-5

## Features
  * Automatic start
  * Chapter splits
  * DLC splits
  * IL splits
  * NG Loadremover
  * NG+ IGT

## Credits
  * [Auddy] (https://github.com/Auddy07) (Founder)
  * [Wipefinger] (https://github.com/Wipefinger) (developer)
  * [Mysterion06](https://github.com/Mysterion06) (developer)
  * [TheDementedSalad) (https://github.com/TheDementedSalad) (developer)
  * [MattMatt] (https://github.com/Mattmatt10111) (developer)
